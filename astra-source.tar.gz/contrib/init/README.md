Sample configuration files for:

SystemD: astrad.service
Upstart: astrad.conf
OpenRC:  astrad.openrc
         astrad.openrcconf
CentOS:  astrad.init
OS X:    org.astra.astrad.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
