#!/bin/bash
# use testnet settings,  if you need mainnet,  use ~/.astracore/astrad.pid file instead
astra_pid=$(<~/.astracore/testnet3/astrad.pid)
sudo gdb -batch -ex "source debug.gdb" astrad ${astra_pid}
